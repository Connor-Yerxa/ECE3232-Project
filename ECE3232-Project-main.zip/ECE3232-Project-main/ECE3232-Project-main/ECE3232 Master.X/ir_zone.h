/* 
 * File:   ir_zone.h
 * Author: tpeters3
 *
 * Created on April 8, 2024, 2:53 PM
 */

#ifndef IR_ZONE_H
#define	IR_ZONE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* IR_ZONE_H */

